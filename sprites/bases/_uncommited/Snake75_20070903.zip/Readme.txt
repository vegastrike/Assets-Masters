Changes:

1) Bartender text use Base.Message(). Messages are drawn in the same way of fixer's messages
2) New yellow "Thanks" for bartender instead the green "Yes"
3) "Yes" and "No" now have transparent background instead gray background.
4) Removed a double button in the minig_bar to retourn in the "Main Concourse"
5) Renamed "yes.png" to "yes.dds"
6) Renamed "no.png" to "no.dds"

Installation:

1) Make a backup of replaced files
2) Unzip to the main Vega Strike folder
3) Run and play
