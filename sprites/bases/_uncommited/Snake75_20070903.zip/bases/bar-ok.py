import fixers
import Base
# Don't like relying on a string value that was not passed, but for now, that is the only way
#Base.EraseObj(Base.GetCurRoom(),"BartenderText")
Base.Message('#f0f0f0You:#000000 #ffff00Thanks For The Talk, Doc')
fixers.DestroyActiveButtons()

