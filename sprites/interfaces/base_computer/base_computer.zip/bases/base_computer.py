#---------------------------------------------------------------------------------
# Vega Strike script for the tutorial quest
# Copyright (C) 2008 Vega Strike team
# Contact: hellcatv@users.sourceforge.net
# Internet: http://vegastrike.sourceforge.net/
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# Author: pyramid (pyramid3d@users.sourceforge.net)
# Version: 2008-12-29
#
# Description:
# This module replaces the coded simple base computer menu
# Use base_computer.MakeBaseComputer instead of Base.Comp
# to link to this computer
#---------------------------------------------------------------------------------
# Features:
# user defined background
# user defined buttons
#
# To Do
# new buttons (maybe animated)
# functionality replacement for all Base.Comp screens
# display planet/base stats, current time, planet sprite

import Base
import GUI
from XGUIDebug import *
import Director
import universe
import VS
import ShowProgress
import methodtype
import mission_lib
import stardate

pirate_bases = { }
quadrants = { }

savefilters = set(["base_computer","New_Game"])

class NewSaveGame: pass

def time_sorted_listdir(dir):
  import os
  def time_key(filename):
    return (-os.stat(dir+'/'+filename).st_mtime, filename)
  return sorted(os.listdir(dir), key=time_key)

def savelist():
  global savefilters
  return [ GUI.GUISimpleListPicker.listitem(path,path) 
    for path in time_sorted_listdir(VS.getSaveDir())
    if path[:1] != '.' and path not in savefilters ]

def makeNewSaveName():
  saves = [ i.data for i in savelist() ]
  prefix = "%s_%s_%s_" % (get_system_text()[2] , get_base_text()[1][0] , get_ship_text())
  i = 1
  while ("%s_%02d" % (prefix,i)) in saves:
    i += 1
  return "%s_%02d" % (prefix,i)

def MakeBaseComputer(room, linkx, linky, enable_missions=1, enable_relations=1, enable_manifest=1, enable_load=1, enable_save=1, return_room_map=0):
  # create the screen
  GUI.GUIInit(1280,1024)
  # 'XXX' prefix means the tooltip will not be displayed
  room_id = Base.Room ('XXXBase_Computer')
  # create an object to keep the state
  comp = BaseComputer(room_id, room, enable_missions, enable_relations, enable_manifest, enable_load, enable_save)
  # link this screen with the room from which the computer was called
  # this will be replaced with a keybinding, eventually
  #if make_links:
  Base.Link (room, 'base_computer', linkx, linky, 0.25, 0.25, 'Computer_Terminal', room_id)
  #Base.Link (room, 'base_computer', linkx, linky, 0.25, 0.25, 'Computer_Terminal', room_id)
  if return_room_map:	
    # They want a room map, pointing to each section separately (right now... only root,
    # but eventually, something else...) and the computer object, so you can do stuff
    room = GUI.GUIRootSingleton.getRoomById(room_id)
    return { 'root':room, 'load':room, 'save':room, 'computer':comp }
  else:
    return room_id

def change_text_click(self,params):
  GUI.GUIButton.onClick(self,params)
  self.room.owner.change_text(self.index)

def scroll_click(self,params):
  GUI.GUIButton.onClick(self,params)
  self.room.owner.scroll(self.index[4:])

def list_picker_click(self,params):
  GUI.GUISimpleListPicker.onClick(self,params)
  self.room.owner.change_selection()

col_header_info  = '#FFFF99' # text color for header
col_text_info    = '#FF6666' # text color for header

class BaseComputer:
  def __init__(self, room_start, room_exit_to, enable_missions, enable_relations, enable_manifest, enable_load, enable_save):
  #def __init__(self, room_start, linkx, linky, enable_missions, enable_relations, enable_manifest, enable_load, enable_save, return_room_map=0):
  #  room_exit_to = room_start
  #  room = room_start
    
    # setup mod variables
    color_font       = GUI.GUIColor(0.10,0.10,0.30) # text color
    color_background = GUI.GUIColor(0.28,0.22,0.33,0.20) # text bg color
    color_selectbg   = GUI.GUIColor(0.25,0.12,0.55) # selected text color
    color_selectfont = GUI.GUIColor(0.50,0.50,1.00) # selected text color

    # Base computer is made up of several "rooms" aka screens
    # the room_start show the user's location
    # this is made a lot more complex because of the need to update the cargo manifest
    guiroom = GUI.GUIRoom(room_start)
    self.guiroom = guiroom
    # when a button is clicked, this will allow us to get the BaseComputer instance from the x_click functions
    guiroom.owner = self
    # add background sprite; no need to keep a variable around for this, as it doesn't change
    #GUI.GUIStaticImage(guiroom, 'background', ( 'interfaces/base_computer/base_computer.sprite' , GUI.GUIRect(0, 0, 1, 1, "normalized") )).draw()
    GUI.GUIStaticImage(guiroom, 'background', ( 'interfaces/base_computer/base_computerani.sprite' , GUI.GUIRect(0, 0, 1, 1, "normalized") )).draw()

    # add buttons
    self.buttons = {}
    self.mode = ''
    self.selection = None

    if enable_manifest:
      hot_loc = GUI.GUIRect(100, 50, 100, 30, "pixel", (1280,1024))
      spr = ("interfaces/base_computer/button_manifest.sprite",hot_loc)
      sprites = { 'enabled':spr, 'disabled':spr, 'down':spr }
      self.add_button( GUI.GUIButton(guiroom,'XXXManifest','btn_manifest', sprites, hot_loc), change_text_click )
    if enable_relations:
      hot_loc = GUI.GUIRect(220, 50, 100, 30, "pixel", (1280,1024))
      spr = ("interfaces/base_computer/button_relations.sprite",hot_loc)
      sprites = { 'enabled':spr, 'disabled':spr, 'down':spr }
      self.add_button( GUI.GUIButton(guiroom,'XXXFinances','btn_relations', sprites, hot_loc), change_text_click )
    if enable_missions:
      hot_loc = GUI.GUIRect(340, 50, 100, 30,"pixel", (1280,1024))
      spr = ("interfaces/base_computer/button_missions.sprite",hot_loc)
      sprites = { 'enabled':spr, 'disabled':spr, 'down':spr }
      self.add_button( GUI.GUIButton(guiroom,'XXXMissions','btn_missions', sprites, hot_loc), change_text_click )
    if enable_load:
      hot_loc = GUI.GUIRect(160, 90, 100, 30, "pixel", (1280,1024))
      spr = ("interfaces/base_computer/button_load.sprite",hot_loc)
      sprites = { 'enabled':spr, 'disabled':spr, 'down':spr }
      self.add_button( GUI.GUIButton(guiroom,'XXXLoad'    ,'btn_load'    , sprites, hot_loc), change_text_click )
    if enable_save:
      hot_loc = GUI.GUIRect(280, 90, 100, 30, "pixel", (1280,1024))
      spr = ("interfaces/base_computer/button_save.sprite",hot_loc)
      sprites = { 'enabled':spr, 'disabled':spr, 'down':spr }
      self.add_button( GUI.GUIButton(guiroom,'XXXSave'    ,'btn_save'    , sprites, hot_loc), change_text_click )
    # Exit button, returns us to concourse
    hot_loc = GUI.GUIRect(460, 50, 100, 30, "pixel", (1280,1024))
    spr = ("interfaces/base_computer/button_exit.sprite",hot_loc)
    sprites = { 'enabled':spr, 'disabled':spr, 'down':spr }
    GUI.GUIRoomButton(guiroom,GUI.GUIRoom(room_exit_to), 'XXXExit','btn_exit',sprites,hot_loc)

    # up and down scroll buttons
    if enable_load or enable_save:
      hot_loc = [ GUI.GUIRect(540, 160, 30, 30, "pixel", (1280,1024)),
        GUI.GUIRect(540, 940, 30, 30, "pixel", (1280,1024)),
        GUI.GUIRect(530, 550, 30, 30, "pixel", (1280,1024)),
        GUI.GUIRect(550, 550, 30, 30, "pixel", (1280,1024)) ]
      spr = [ ("interfaces/quine/up_pressed.spr", hot_loc[0]),
        ("interfaces/quine/down_pressed.spr", hot_loc[1]),
        ("interfaces/quine/left_pressed.spr", hot_loc[2]),
        ("interfaces/quine/right_pressed.spr", hot_loc[3]) ]
      sprites = [ { 'enabled':None, 'disabled':None, 'down':spr[0] },
        { 'enabled':None, 'disabled':None, 'down':spr[1] },
        { 'enabled':None, 'disabled':None, 'down':spr[2] },
        { 'enabled':None, 'disabled':None, 'down':spr[3] } ]
      self.add_button( GUI.GUIButton(guiroom,'XXXUp'   ,'btn_up'   , sprites[0], hot_loc[0]), scroll_click )
      self.add_button( GUI.GUIButton(guiroom,'XXXDown' ,'btn_down' , sprites[1], hot_loc[1]), scroll_click )
      #self.add_button( GUI.GUIButton(guiroom,'XXXLeft' ,'btn_left' , sprites[2], hot_loc[2]), scroll_click )
      #self.add_button( GUI.GUIButton(guiroom,'XXXRight','btn_right', sprites[3], hot_loc[3]), scroll_click )

    # text and picker screen background
    screen_loc = GUI.GUIRect(70,170,460,760,"pixel",(1280,1024))
    GUI.GUIStaticImage(guiroom, 'text_screen', ( 'interfaces/base_computer/textbox.sprite', GUI.GUIRect(50,150,500,800,"pixel",(1280,1024)) )).draw()
    # picker screen
    self.picker_screen = GUI.GUISimpleListPicker(guiroom,'XXXSelect item','picker_screen', screen_loc,
      textcolor=color_font, textbgcolor=color_background,selectedcolor=color_selectfont, selectedbgcolor=color_selectbg)
    self.picker_screen.onClick = methodtype.methodtype(list_picker_click, self.picker_screen, type(self.picker_screen))
    self.picker_screen.hide()
    # text screen
    self.txt_screen = GUI.GUIStaticText(guiroom, 'txt_screen', 'txt_screen', screen_loc,color=color_font,bgcolor=color_background)
    self.txt_screen.hide()
    # info screen
    #screen_loc = GUI.GUIRect(600,150,500,800,"pixel",(1280,1024))
    GUI.GUIStaticImage(guiroom, 'info_screen', ( 'interfaces/base_computer/textbox.sprite', GUI.GUIRect(600,150,500,800,"pixel",(1280,1024)) )).draw()
    self.info_screen = GUI.GUIStaticText(guiroom,'info_screen', 'info_screen', GUI.GUIRect(620,170,460,760,"pixel",(1280,1024)),color=color_font,bgcolor=color_background)
    text = get_info_text(universe.getDockedBase())
    self.info_screen.setText(text)
    self.info_screen.show()

  def reset(self):
    trace(TRACE_DEBUG,"::: BaseComputer.reset()")
    self.txt_screen.setText('')

  def change_selection(self):
    print 'Change selection'

  def change_text(self, button_index):
    text_screens = {
      'btn_relations' : lambda:get_relations_text(VS.getPlayer()),
      'btn_manifest' : lambda:get_manifest_text(VS.getPlayer()) #,
      #'btn_missions' : lambda:get_missions_text()
      }
    if button_index in text_screens:
      self.txt_screen.setText( text_screens[button_index]() )
      self.txt_screen.show()
      #self.info_screen.show()
      self.picker_screen.hide()
    elif button_index == "btn_missions":
      print "btn_missions selection: " + str(self.picker_screen.selection)
      if self.mode != button_index:
        self.picker_screen.items = get_missions_text(1)
        self.picker_screen.show()
        self.txt_screen.hide()
      elif self.picker_screen.selection is not None:
        #self.selection = self.picker_screen.selection
        items = get_missions_text(2)
        print "Items: " + str(items[0])
        #self.info_screen.setText(items[self.picker_screen.selection])
        #self.info_screen.setText('Heyho')
    elif button_index == "btn_load":
      if self.mode != button_index:
        self.picker_screen.items = savelist()
        self.picker_screen.show()
        self.txt_screen.hide()
      elif self.picker_screen.selection is not None:
        ShowProgress.activateProgressScreen('loading',3)
        import dj_lib
        dj_lib.enable()
        VS.loadGame(self.picker_screen.items[self.picker_screen.selection].data)
    elif button_index == "btn_save":
      if self.mode != button_index:
        self.picker_screen.items = [GUI.GUISimpleListPicker.listitem("New Game",NewSaveGame)]+savelist()
        self.picker_screen.show()
        self.txt_screen.hide()
      elif self.picker_screen.visible and self.picker_screen.items[self.picker_screen.selection].data is not NewSaveGame:
        self.picker_screen.hide()
        self.txt_screen.setText( 
          "\n"*7+
          "Are you sure you want to overwrite the savegame?\n(%s)"%
            self.picker_screen.items[self.picker_screen.selection]
          +"\n"*3
          +"Press SAVE again to do it." )
        self.txt_screen.show()
      elif self.picker_screen.selection is not None:
        if self.picker_screen.items[self.picker_screen.selection].data is NewSaveGame:
          VS.saveGame(makeNewSaveName())
        else:
          VS.saveGame(self.picker_screen.items[self.picker_screen.selection].data)
        self.picker_screen.items = [GUI.GUISimpleListPicker.listitem("New Game",NewSaveGame)]+savelist()
        self.picker_screen.show()
        self.txt_screen.hide()
    else:
      self.picker_screen.hide()
      self.txt_screen.hide()
    self.mode = button_index
	
  def scroll(self,direction):
		list_screens = set(['btn_load','btn_save'])
		if self.mode in list_screens:
			if direction == 'up':
				self.picker_screen.pageMove(-1)
			elif direction == 'down':
				self.picker_screen.pageMove(1)
			elif direction == 'left':
				self.picker_screen.viewMove(-1)
			elif direction == 'right':
				self.picker_screen.viewMove(1)

  def add_button(self, guibutton, onclick_handler):
		# add the button to the "buttons" dictionary, draw it, and add onclick handler
		self.buttons[guibutton.index] = guibutton
		guibutton.draw()
		guibutton.onClick = methodtype.methodtype(onclick_handler, guibutton, type(guibutton))
	
  def setMode(self,mode):
		aliases = dict(load='btn_load',save='btn_save',missions='btn_missions')
		mode = aliases.get(mode,mode)
		if self.mode != mode:
			self.change_text(mode)
		self.guiroom.redrawIfNeeded()

#
#   display screen functions
#

# mission descriptions
def get_missions_text(return_index=1):
  text_missions = []
  text_descriptons = []
  #show available missions
  plr = mission_lib.getMissionPlayer()
  for i in range(Director.getSaveStringLength(plr, "mission_scripts")):
    script=Director.getSaveString(plr,"mission_scripts",i)
    # get only mission bbs scripts
    if script.find("#F#")==-1 and script.find("#G#")==-1:
      names=Director.getSaveString(plr, "mission_names",i)
      desc=Director.getSaveString(plr,"mission_descriptions",i)
      mvars=Director.getSaveString(plr,"mission_vars",i)
      #print "Mission: " + str(script) + str(mvars) + "\n" + str(names) +"\n" + str(desc) +"\n"
      text_missions += [names]
      text_descriptons += [desc]
  if return_index == 1:
    return text_missions
  else:
    return text_descriptons
  #show active missions
  missionlist = mission_lib.GetMissionList()
  parth = lambda s:(s and "("+s+")") or s
  full_layout = "\n\nMissions:\n\n%(ENTRIES)s\n\nTotal active missions: %(NUM_MISSIONS)s\n";
  entry_process = lambda e: { 
    'MISSION_TYPE'		:e.get('MISSION_TYPE','MISSION').replace('_',' ').capitalize(), 
    'SHORT_DESCRIPTION'	:e.get('MISSION_SHORTDESC','').split('/',1)[-1],
    'GUILD_NAME' 		:parth(e.get('GUILD_NAME',e.get('MISSION_NAME','').split('/',1)[0]).replace('_',' ').title()) }
  entry_layout = "%(MISSION_TYPE)s %(GUILD_NAME)s:\n%(SHORT_DESCRIPTION)s\n\n"
  return full_layout % {
    'NUM_MISSIONS':len(missionlist),
    'ENTRIES':''.join( entry_layout % entry_process(entry) for entry in missionlist ) }

def get_info_text(current_base):
  str_quadrant, str_sector, str_system = get_system_text(current_base=current_base)
  (int_faction,str_faction),(str_base,str_base_type) = get_base_text(current_base)
  str_date = stardate.formatStarDate(int_faction,VS.GetGameTime())
  str_ship = VS.getPlayer().getName()
  str_location = col_header_info+'Current Time: '+col_text_info+str_date+'\n\n' + col_header_info+'Location: '+col_text_info+str_base+' - '+str_base_type.capitalize()+' ['+str_faction+']\n\n'
  str_location += col_header_info+'System: '+col_text_info+str_system+col_header_info+' in '+col_text_info+str_sector+col_header_info+' Sector\n\n'
  str_location += col_header_info+'Ship: ' +col_text_info+ str_ship + '\n\n'
  str_location += col_header_info+'Cash: ' +col_text_info+ str(int(VS.getPlayer().getCredits()))+'\n\n'
  str_location += col_header_info+'Active mission: ' +col_text_info+ str(len(mission_lib.GetMissionList()))
  return str_location

def get_manifest_text(player):
	cargo_dict = {}
	# get the hold volume
	int_hold_volume = int( VS.LookupUnitStat( player.getName(), player.getFactionName(), "Hold_Volume" ) )
	if (player.hasCargo("add_cargo_volume")):
		# capacity increases by 50% if they have the cargo expansion
		int_hold_volume = int( int_hold_volume * 1.5 )
	int_total_quantity = 0
	for i in range(player.numCargo()):
		cargo = player.GetCargoIndex(i)
		name     = cargo.GetContent()
		category = cargo.GetCategory()
		quantity = cargo.GetQuantity()
		if name == '': continue
		if category[:8] == 'upgrades': continue
		if category[:9] == 'starships': continue
		if (quantity > 0):
			cargo_dict[name] = quantity
			int_total_quantity += quantity
	int_space_left = int_hold_volume - int_total_quantity
	keys = cargo_dict.keys()
	if len(keys) > 0:
		str_manifest = "Space left: %s\n\n" %(int_space_left)
		keys.sort()
		for i in keys:
			count = cargo_dict[i]
			# try to pad the columns so they line up
			str_pad = "   "
			int_pad_len = len(str_pad) - len(str(count))
			if int_pad_len < 1:
				str_pad = ""
			else:
				str_pad = str_pad[:int_pad_len]
			str_manifest += "%s%s  %s\n" %(str_pad, count, i)
	else:
		str_manifest = "Space left: %s\nNo cargo loaded.\n" %(int_space_left)
	return str_manifest

#gets the faction relations and kills
def get_relations_text(player):
  str_relations = "Cash:  %s\n\nKill breakdown:\n" %( int(player.getCredits()) )
  # length of faction_kills = VS.GetNumFactions() + 1
  # could the last entry be the total?  or maybe the number of times the user has died?
  faction_kills = [];
  for i in range(Director.getSaveDataLength( VS.getCurrentPlayer(), 'kills' )):
    faction_kills.append( Director.getSaveData( VS.getCurrentPlayer(), 'kills', i ) )
  #displayed_factions = ['confed', 'aera', 'rlaan', 'aeran_merchant_marine']
  displayed_factions = ["privateer","aera","andolian","confed","dgn","forsaken","highborn","homeland-security","hunter","ISO","klkk","LIHW","luddites","mechanist","merchant_guild","pirates","purist","shaper","shmrn","rlaan","rlaan_briin","uln","unadorned","aeran_merchant_marine","andolian_citizen","dgn_citizen","forsaken_citizen","highborn_citizen","klkk_citizen","LIHW_citizen","mechanist_citizen","merchant_guild_citizen","purist_citizen","rlaan_citizen","shaper_citizen","shmrn_citizen","uln_citizen","unadorned_citizen"]
  for i in range(VS.GetNumFactions()):
    # VS.GetFactionIndex(s) expects a string
    # VS.GetFactionIndex(s) expects a name
    faction = VS.GetFactionName(i)
    if faction in displayed_factions:
      # note: the following calls do not always return equal values:
      #   VS.GetRelation(a, b)
      #   VS.GetRelation(b, a)
      relation = int( VS.GetRelation(faction, player.getFactionName()) * 100 )
      if relation > 100:
        relation = 100
      elif relation < -100:
        relation = -100
      # not sure if the AI or Friend/Foe radar agree with these figures, but this ought to work, mostly
      if relation > 20:
        str_relation = "friendly"
      elif relation >= 0:
        str_relation = "neutral"
      elif relation > -20:
        str_relation = "hostile"
      else:
        str_relation = "kill on sight"
      try:
        kills = int( faction_kills[i] )
      except:
        kills = 0
      # add current faction to the output string
      #str_relations = str_relations + "%s%s  %s\t(%s: %s)\n" %(str_pad, kills, faction.capitalize(), str_relation, relation)
      str_relations = str_relations + "%s: %s (%s)\t(kills: %s)\n" %(faction.capitalize(), relation, str_relation, kills)
  return str_relations

#
#   helper functions
#

# gets current system information
def get_system_text(str_system_file=None, current_base=None):
	if str_system_file is None:
		if current_base is None:
			current_base = universe.getDockedBase()
		# get sector, quadrant, system, and base name
		str_system_file = current_base.getUnitSystemFile()

	n = str_system_file.find('/')
	if (n >= 0):
		str_sector   = str_system_file[:n]
		str_system   = str_system_file[n+1:]
	else:
		str_sector   = 'Unknown'
		str_system   = 'Unknown'

	try:
		str_quadrant = quadrants[str_system_file]
	except KeyError:
		str_quadrant = 'Unknown'
		
	return (str_quadrant,str_sector,str_system)

# description of current base
def get_base_text(current_base = None, str_system_file = None):
	if current_base is None:
		current_base = universe.getDockedBase()

	if not current_base:
		return ((0,"neutral"),("Unknown","Main Menu"))
	if str_system_file is None:
		# get sector, quadrant, system, and base name
		str_system_file = current_base.getUnitSystemFile()
	
	# get faction
	int_faction = current_base.getFactionIndex()
	str_faction = current_base.getFactionName()

	# bases and planets aren't consistent in their usage of Name and Fullname values
	if not current_base:
		import debug
		debug.error('getDockedBase() returns null Unit!')
	if current_base.isPlanet():
		str_base = current_base.getName()
		str_base_type = current_base.getFullname() + " planet"
	else:
		str_base = current_base.getFullname()
		str_base_type = current_base.getName()
		if str_base == '':
			str_base = 'Unknown'
			if str_faction == "pirates":
				try:
					str_base = pirate_bases[str_system_file]
				except KeyError:
					str_base = 'Unknown'

	return ((int_faction,str_faction),(str_base,str_base_type))

# player's ship info
def get_ship_text(unit = None):
	if unit is None:
		player = VS.getPlayer()
	name = player.getName()
	if name.index('.') is None:
		return name.capitalize()
	else:
		return name[:name.index('.')].capitalize()
