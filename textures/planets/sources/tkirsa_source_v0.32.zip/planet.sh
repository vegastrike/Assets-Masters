#!/bin/sh
#//////////////////////////////////////////////////////////////////////////////////
#// Persistence of Vision Ray Tracer Shell Script
#// File       : planet.sh
#// Description: script for calling ini or pov files rendering
#// Version    : 1.00
#// Date       : 2008-01-12
#// Author     : Pyramid
#// Internet   : http://space3d.no.sapo.pt/
#// Scale      : 1 POV Unit = 1km
#//////////////////////////////////////////////////////////////////////////////////
#
# single render from POV file
#povray +Iplanet_preview.pov +A0.3 +W320 +H240 +P
#povray +Iplanet_preview.pov +A0.3 +W640 +H480 +P
#povray +Iplanet_preview.pov +A0.3 +W1280 +H1024 +P
#
# multiple render from INI file
povray planet_preview.ini +Iplanet_preview.pov
#povray planet_gallery.ini +Iplanet_gallery.pov
