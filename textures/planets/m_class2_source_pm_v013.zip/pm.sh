#!/bin/sh
#// ---------------------------------------------------------------------------
#// Space3D
#// Free POV-Ray script for space scenes rendering
#// Copyright (C) 2005, 2006, 2007 Pyramid
#// Contact: pedrabella@sapo.pt
#// Internet: http://space3d.no.sapo.pt/
#//
#// This script is distributed with ABSOLUTELY NO WARRANTY;
#// See the GNU General Public License for more details,
#// which can be found in doc/SPACE3D_LICENSE.txt
#//
#// Persistence of Vision Ray Tracer Shell Script
#// File       : planetmaker.sh
#// Description: script for calling ini or pov files rendering
#// Version    : 0.26
#// Date       : 2007-08-10
#// Author     : Pyramid
#// Internet   : http://space3d.no.sapo.pt/
#// Scale      : 1 POV Unit = 1km
#// ---------------------------------------------------------------------------
#Output_File_Type=N ;N=png; C=tga compressed; S=system,bmp; T=tga uncompressed
#
# single render from POV file
#povray +Iplanetmaker.pov +A0.3 +W320 +H240 +FN +P
#povray +Iplanetmaker.pov +A0.3 +W640 +H480 +FN +P
#povray +Iplanetmaker.pov +A0.3 +W1280 +H1024 +FN +P
#
# multiple render from INI file
povray planetmaker.ini +Iplanetmaker.pov +FN
#povray planetmaker.ini +Iplanetmaker.pov
