povray starfield_example.ini +Istarfield_example.pov
 
